import React from 'react';
import ClientService from '../services/ClientService';

class ClientComponent extends React.Component{

    constructor(props){
        super(props)
        this.state = {
            clients:[]
        }
    }

    componentDidMount(){
        ClientService.getClients().then((response) => {
            this.setState({ clients: response.data})
        });
    }

    render(){
        return (
            <div>
                <h1 className = "text-centre"> Clients List</h1>
                <table className = "table table-striped">
                    
                    <thead>
                        <tr>

                            <td> Client Id</td>
                            <td> Client Name</td>
                            <td> Client Gender</td>
                            <td> Client Email Id</td>
                        </tr>

                    </thead>
                    <tbody>
                        {
                            this.state.clients.map(
                                client =>
                                <tr key = {client.id}>
                                     <td> {client.id}</td>
                                     <td> {client.name}</td>
                                     <td> {client.gender}</td>
                                     <td> {client.email}</td>
                                </tr>
                            )
                        }

                    </tbody>
                </table>

            </div>

        )
    }
} 

export default ClientComponent
