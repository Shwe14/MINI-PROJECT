import React from 'react';
import logo  from './logo.svg';
import './App.css';
import ClientComponent from './components/ClientComponent';

function App() {
  return (
    <div className="App">
      <ClientComponent/>
    </div>
  );
}

export default App;
