package net.mpbk.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniprojectBkApplicationTests {

	@Test
	void contextLoads() {
	}

}
