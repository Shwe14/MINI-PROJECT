package net.mpbk.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import net.mpbk.springboot.repository.ClientRepository;
import net.mpbk.springboot.model.Client;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniprojectBkApplication implements CommandLineRunner{ 

	public static void main(String[] args) {
		SpringApplication.run(MiniprojectBkApplication.class, args);
	}

	@Autowired
	private ClientRepository clientRepository;
	
	@Override
	public void run(String... args) throws Exception {
		this.clientRepository.save(new Client("Sumathi","Female","sumathi@gmail.com"));
		this.clientRepository.save(new Client("Sachin","Male","sachin@gmail.com"));
		this.clientRepository.save(new Client("Abisha","Female","abisha@gmail.com"));
		
		
		
	
	}
	
	}
	

