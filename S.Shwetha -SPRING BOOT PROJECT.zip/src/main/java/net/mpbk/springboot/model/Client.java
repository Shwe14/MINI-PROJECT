package net.mpbk.springboot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "clients")
public class Client {
	
	@Id
	@GeneratedValue(strategy = GenerationType. IDENTITY)
	private long id;
	
	@Column(name= "Name")
	private String Name;
	
	@Column(name=" Gender")
	private String Gender;
	
	private String email;
	
	public Client() {
		
	}
	
	public Client(String name, String gender, String email) {
		super();
		Name = name;
		Gender = gender;
		this.email = email;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
