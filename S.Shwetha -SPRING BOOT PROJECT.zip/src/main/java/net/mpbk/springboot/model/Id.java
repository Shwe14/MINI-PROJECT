package net.mpbk.springboot.model;

public @interface Id {

}
